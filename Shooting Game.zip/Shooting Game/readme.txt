Run the Shooting Game.py file to start the game.

Image/Sound Sources

Background: http://hkbus.wikia.com/wiki/%E6%AA%94%E6%A1%88:HKUST_Sundial_JCAtrium.JPG
Red bird: http://utranet.ust.hk/work/logo/aboutlogo/home.html
Closed book: http://www.clipartpal.com/clipart_pd/education/books_10067.html
Open book: http://www.clipartpal.com/clipart_pd/education/books_10085.html
Pen: http://roomofluxury.co.uk/gifts/johannes-brahms-special-edition-ballpoint-pen.html
Huh sound: http://www.freesound.org/people/sandyrb/sounds/85897/
Victory sound: http://www.freesound.org/people/AlaskaRobotics/sounds/221567/
Enemy hit sound: http://www.freesound.org/people/adcbicycle/sounds/13927/
Gameover sound: http://www.freesound.org/people/fins/sounds/171673/